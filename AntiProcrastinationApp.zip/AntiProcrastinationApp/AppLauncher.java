import model.User;
import service.AuthService;

import java.util.Scanner;

public class AppLauncher {
    private static final Scanner scanner = new Scanner(System.in);
    private static final AuthService authService = new AuthService();
    private static User currentUser = null;

    public static void main(String[] args) {
        System.out.println("🎯 Welcome to Anti-Procrastination Task Manager!");

        while (true) {
            if (currentUser == null) {
                showAuthMenu();
            } else {
                showTaskMenu();
            }
        }
    }

    private static void showAuthMenu() {
        System.out.println("\n1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit");
        System.out.print("Choose: ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1": register(); break;
            case "2": login(); break;
            case "3": System.out.println("👋 Goodbye!"); System.exit(0);
            default: System.out.println("❌ Invalid option.");
        }
    }

    private static void register() {
        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Phone: ");
        String phone = scanner.nextLine();

        System.out.print("Password: ");
        String pwd = scanner.nextLine();

        boolean success = authService.register(name, phone, pwd);
        if (success) System.out.println("🎉 You can now login.");
    }

    private static void login() {
        System.out.print("Phone: ");
        String phone = scanner.nextLine();

        System.out.print("Password: ");
        String pwd = scanner.nextLine();

        currentUser = authService.login(phone, pwd);
    }

    private static void showTaskMenu() {
        System.out.println("\n🧠 Task Dashboard (User: " + currentUser.getName() + ")");
        System.out.println("1. View Tasks");
        System.out.println("2. Add Task");
        System.out.println("3. Logout");
        System.out.print("Choose: ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1": System.out.println("📋 [Task List Feature Coming Soon!]"); break;
            case "2": System.out.println("📝 [Add Task Feature Coming Soon!]"); break;
            case "3": currentUser = null; break;
            default: System.out.println("❌ Invalid option.");
        }
    }
}
