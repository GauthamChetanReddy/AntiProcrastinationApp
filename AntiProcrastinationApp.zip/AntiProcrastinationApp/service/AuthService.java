package service;

import model.User;

import java.util.ArrayList;
import java.util.List;

public class AuthService {
    // 🧠 In-memory user list
    private static List<User> users = new ArrayList<>();

    // 🔐 Method to register or return existing user
    public static User registerOrLogin(String name) {
        for (User user : users) {
            if (user.getName().equalsIgnoreCase(name)) {
                return user; // 🔁 Existing user
            }
        }

        // 🆕 Create new user
        String userId = "U" + (users.size() + 1);
        User newUser = new User(userId, name);
        users.add(newUser);
        return newUser;
    }

    // (Optional) Method to get all users - could be useful later
    public static List<User> getAllUsers() {
        return users;
    }
}
