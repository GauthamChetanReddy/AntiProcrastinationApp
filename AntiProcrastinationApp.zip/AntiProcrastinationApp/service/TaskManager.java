// ✅ TaskManager.java (inside service package)
package service;

import model.Task;
import java.util.*;

public class TaskManager {

    public static void saveTask(Task task) {
        List<Task> tasks = FileManager.loadTasks("data/tasks.txt");
        tasks.add(task);
        FileManager.saveAllTasks(tasks);
    }

    public static List<Task> getTasksForUser(String userId) {
        List<Task> all = FileManager.loadTasks("data/tasks.txt");
        List<Task> filtered = new ArrayList<>();
        for (Task t : all) {
            if (t.getOwnerId().equals(userId)) {
                filtered.add(t);
            }
        }
        return filtered;
    }

    public static void markTaskAsCompleted(String taskId, String userId) {
        List<Task> tasks = FileManager.loadTasks("data/tasks.txt");
        for (Task t : tasks) {
            if (t.getId().equals(taskId) && t.getOwnerId().equals(userId)) {
                t.setStatus("done");
                break;
            }
        }
        FileManager.saveAllTasks(tasks);
    }

    public static void deleteTask(String taskId, String userId) {
        List<Task> tasks = FileManager.loadTasks("data/tasks.txt");
        tasks.removeIf(t -> t.getId().equals(taskId) && t.getOwnerId().equals(userId));
        FileManager.saveAllTasks(tasks);
    }

    public static List<Task> getTasksByStatus(String userId, String status) {
        List<Task> tasks = FileManager.loadTasks("data/tasks.txt");
        List<Task> filtered = new ArrayList<>();
        for (Task t : tasks) {
            if (t.getOwnerId().equals(userId) && t.getStatus().equalsIgnoreCase(status)) {
                filtered.add(t);
            }
        }
        return filtered;
    }

    public static int getCompletedTaskCount(String userId) {
        int count = 0;
        List<Task> tasks = getTasksForUser(userId);
        for (Task t : tasks) {
            if ("done".equalsIgnoreCase(t.getStatus())) {
                count++;
            }
        }
        return count;
    }
}
