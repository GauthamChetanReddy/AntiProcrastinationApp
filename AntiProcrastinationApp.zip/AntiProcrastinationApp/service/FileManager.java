package service;

import model.Task;
import model.TimerSession;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileManager {

    public static List<String> readLines(String path) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null)
                lines.add(line);
        } catch (IOException e) {
            // file might not exist initially, return empty list
        }
        return lines;
    }

    public static void writeLines(String path, List<String> lines) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (String l : lines)
                bw.write(l + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Task> loadTasks(String path) {
        List<Task> tasks = new ArrayList<>();
        for (String line : readLines(path)) {
            tasks.add(Task.fromString(line));
        }
        return tasks;
    }

    public static void saveAllTasks(List<Task> tasks) {
        List<String> lines = new ArrayList<>();
        for (Task t : tasks) {
            lines.add(t.toString());
        }
        writeLines("data/tasks.txt", lines);
    }

    public static void saveAllTimerSessions(List<TimerSession> sessions) {
        List<String> lines = new ArrayList<>();
        for (TimerSession t : sessions) {
            lines.add(t.toString());
        }
        writeLines("data/timer_sessions.txt", lines);
    }
}
