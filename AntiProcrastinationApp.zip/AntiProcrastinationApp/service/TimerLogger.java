// ✅ TimerLogger.java (inside service package)
package service;

import model.TimerSession;
import java.util.*;

public class TimerLogger {
    public static void logTimerSession(String userId, String taskId, int mins) {
        List<TimerSession> sessions = getSessionsForUser(userId);
        String timestamp = String.valueOf(System.currentTimeMillis());
        TimerSession s = new TimerSession(userId, taskId, mins, timestamp);
        sessions.add(s);
        FileManager.saveAllTimerSessions(sessions);
    }

    public static List<TimerSession> getSessionsForUser(String userId) {
        List<TimerSession> list = new ArrayList<>();
        for (String line : FileManager.readLines("data/timer_sessions.txt")) {
            TimerSession s = TimerSession.fromString(line);
            if (s.getUserId().equals(userId)) {
                list.add(s);
            }
        }
        return list;
    }
    public static void logSession(TimerSession session) {
    List<TimerSession> sessions = getSessionsForUser(session.getUserId());
    sessions.add(session);
    FileManager.saveAllTimerSessions(sessions);
}

    public static int getTotalMinutes(String userId) {
        int total = 0;
        List<TimerSession> sessions = getSessionsForUser(userId);
        for (TimerSession s : sessions) {
            total += s.getMinutes();
        }
        return total;
    }

}