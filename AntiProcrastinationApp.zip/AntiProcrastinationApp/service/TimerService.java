package service;

import model.TimerSession;
import java.time.LocalDateTime;

public class TimerService {

    // Basic timer (without logging)
    public static void startTimer(int minutes) {
        System.out.println("⏳ Timer started for " + minutes + " minute(s)...");

        try {
            Thread.sleep(minutes * 60 * 1000); // For testing, reduce this time
        } catch (InterruptedException e) {
            System.out.println("⚠️ Timer interrupted");
        }

        System.out.println("✅ Time's up! Well done!");
    }

    // Timer with session logging
    public static void startTimerWithLogging(String userId, String taskId, int minutes) {
        System.out.println("⏳ Timer started for " + minutes + " minute(s)...");

        try {
            Thread.sleep(minutes * 60 * 1000); // For testing, reduce time
        } catch (InterruptedException e) {
            System.out.println("⚠️ Timer interrupted");
        }

        System.out.println("✅ Time's up! Well done!");

        String timestamp = LocalDateTime.now().toString();
        TimerSession session = new TimerSession(userId, taskId, minutes, timestamp);
        TimerLogger.logSession(session);
    }
}
