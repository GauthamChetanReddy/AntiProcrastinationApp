package ui;

import javax.swing.*;
import java.awt.*;

public class RegisterPanel extends JPanel {
    public RegisterPanel(MainWindow mainWindow) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        setBackground(Color.WHITE);

        JLabel title = new JLabel("📝 Register");
        title.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(15);

        JLabel phoneLabel = new JLabel("Phone:");
        JTextField phoneField = new JTextField(15);

        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField(15);

        JButton registerBtn = new JButton("Register");
        JButton loginBtn = new JButton("Back to Login");

        // Layout
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1; add(nameLabel, gbc);
        gbc.gridx = 1; add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; add(phoneLabel, gbc);
        gbc.gridx = 1; add(phoneField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; add(passLabel, gbc);
        gbc.gridx = 1; add(passField, gbc);

        gbc.gridx = 0; gbc.gridy = 4; add(registerBtn, gbc);
        gbc.gridx = 1; add(loginBtn, gbc);

        // Button Actions
        loginBtn.addActionListener(e -> mainWindow.switchTo("login"));
    }
}
