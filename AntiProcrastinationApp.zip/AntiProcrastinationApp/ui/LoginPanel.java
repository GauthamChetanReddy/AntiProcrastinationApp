package ui;

import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {
    public LoginPanel(MainWindow mainWindow) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        setBackground(Color.WHITE);

        JLabel title = new JLabel("🔐 Login");
        title.setFont(new Font("Arial", Font.BOLD, 24));

        JLabel phoneLabel = new JLabel("Phone:");
        JTextField phoneField = new JTextField(15);

        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField(15);

        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        // Layout
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 1; add(phoneLabel, gbc);
        gbc.gridx = 1; add(phoneField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; add(passLabel, gbc);
        gbc.gridx = 1; add(passField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; add(loginBtn, gbc);
        gbc.gridx = 1; add(registerBtn, gbc);

        // Button Actions
        registerBtn.addActionListener(e -> mainWindow.switchTo("register"));
    }
}
