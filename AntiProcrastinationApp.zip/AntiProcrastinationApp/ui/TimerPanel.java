package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TimerPanel extends JPanel {
    private JLabel timerLabel;
    private JButton startButton, stopButton, resetButton;
    private Timer timer;
    private int timeLeft = 25 * 60; // 25 minutes

    public TimerPanel() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("⏳ Focus Timer"));

        timerLabel = new JLabel(formatTime(timeLeft), SwingConstants.CENTER);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 36));

        JPanel buttonPanel = new JPanel();
        startButton = new JButton("▶ Start");
        stopButton = new JButton("⏹ Stop");
        resetButton = new JButton("🔄 Reset");

        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(resetButton);

        add(timerLabel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Timer logic: tick every second
        timer = new Timer(1000, e -> {
            timeLeft--;
            timerLabel.setText(formatTime(timeLeft));
            if (timeLeft <= 0) {
                timer.stop();
                JOptionPane.showMessageDialog(this, "⏰ Time's up! Take a short break.");
            }
        });

        startButton.addActionListener(e -> timer.start());
        stopButton.addActionListener(e -> timer.stop());
        resetButton.addActionListener(e -> {
            timer.stop();
            timeLeft = 25 * 60;
            timerLabel.setText(formatTime(timeLeft));
        });
    }

    private String formatTime(int totalSeconds) {
        int min = totalSeconds / 60;
        int sec = totalSeconds % 60;
        return String.format("%02d:%02d", min, sec);
    }
}
