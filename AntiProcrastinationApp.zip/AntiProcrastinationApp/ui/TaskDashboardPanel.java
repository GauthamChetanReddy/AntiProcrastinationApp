package ui;

import model.Task;
import model.User;
import service.TaskManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class TaskDashboardPanel extends JPanel {
    private User user;
    private DefaultListModel<String> taskListModel;
    private JList<String> taskList;

    public TaskDashboardPanel(User user) {
        this.user = user;
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createTitledBorder("📋 Your Tasks"));

        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        loadTasks();

        JScrollPane scrollPane = new JScrollPane(taskList);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton markDoneBtn = new JButton("✅ Mark Done");
        JButton deleteBtn = new JButton("🗑️ Delete Task");
        JButton refreshBtn = new JButton("🔄 Refresh");

        buttonPanel.add(markDoneBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(refreshBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        // ✅ Mark as Done
        markDoneBtn.addActionListener(e -> {
            int idx = taskList.getSelectedIndex();
            if (idx != -1) {
                String raw = taskListModel.get(idx);
                String id = raw.split(":")[0];
                TaskManager.markTaskCompleted(id.trim());
                JOptionPane.showMessageDialog(this, "✅ Task marked completed!");
                loadTasks();
            }
        });

        // ❌ Delete
        deleteBtn.addActionListener(e -> {
            int idx = taskList.getSelectedIndex();
            if (idx != -1) {
                String raw = taskListModel.get(idx);
                String id = raw.split(":")[0];
                TaskManager.deleteTask(id.trim());
                JOptionPane.showMessageDialog(this, "🗑️ Task deleted.");
                loadTasks();
            }
        });

        // 🔁 Refresh
        refreshBtn.addActionListener(e -> loadTasks());
    }

    private void loadTasks() {
        taskListModel.clear();
        List<Task> tasks = TaskManager.getTasksForUser(user.getId());
        for (Task t : tasks) {
            String display = t.getId() + ": " + t.getDescription() + " [" + t.getStatus() + "]";
            taskListModel.addElement(display);
        }
    }
}
