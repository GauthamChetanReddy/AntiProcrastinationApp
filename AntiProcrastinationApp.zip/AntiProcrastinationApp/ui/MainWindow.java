package ui;

import model.Task;
import model.User;
import service.TaskManager;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MainWindow extends JFrame {
    private User currentUser;
    private JTextArea taskDisplay;

    public MainWindow() {
        setTitle("🎯 Anti-Procrastination Task Manager");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        showLoginScreen();
    }

    private void showLoginScreen() {
        JPanel panel = new JPanel(new BorderLayout());
        JTextField nameField = new JTextField(20);
        JButton loginBtn = new JButton("Login");

        panel.add(new JLabel("👤 Enter your name:"), BorderLayout.NORTH);
        panel.add(nameField, BorderLayout.CENTER);
        panel.add(loginBtn, BorderLayout.SOUTH);

        setContentPane(panel);

        loginBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (!name.isEmpty()) {
                currentUser = service.AuthService.registerOrLogin(name);
                showTaskDashboard();
            } else {
                JOptionPane.showMessageDialog(this, "Name cannot be empty.");
            }
        });

        revalidate();
        repaint();
    }

    private void showTaskDashboard() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel title = new JLabel("✅ Welcome, " + currentUser.getName(), SwingConstants.CENTER);
        panel.add(title, BorderLayout.NORTH);

        taskDisplay = new JTextArea(10, 40);
        taskDisplay.setEditable(false);
        panel.add(new JScrollPane(taskDisplay), BorderLayout.CENTER);
        TimerPanel timerPanel = new TimerPanel();
        panel.add(timerPanel, BorderLayout.EAST);


        JButton addTaskBtn = new JButton("➕ Add Task");
        addTaskBtn.addActionListener(e -> addNewTask());
        panel.add(addTaskBtn, BorderLayout.SOUTH);

        setContentPane(panel);
        loadTasks();
        revalidate();
        repaint();
    }

    private void loadTasks() {
        List<Task> tasks = TaskManager.getTasksForUser(currentUser.getId());
        StringBuilder sb = new StringBuilder();
        for (Task t : tasks) {
            sb.append("• ").append(t.getDescription()).append("\n");
        }
        taskDisplay.setText(sb.toString());
    }

    private void addNewTask() {
        String desc = JOptionPane.showInputDialog(this, "Enter task:");
        if (desc != null && !desc.trim().isEmpty()) {
            Task task = new Task(currentUser.getId(), desc.trim());
            TaskManager.saveTask(task);
            loadTasks();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}
