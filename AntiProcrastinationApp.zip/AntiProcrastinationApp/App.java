// App.java
import model.Task;
import model.User;
import service.AuthService;
import service.TaskManager;
import service.TimerLogger;
import service.TimerService;

import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String name = sc.nextLine().trim();

        User loggedInUser = AuthService.registerOrLogin(name);

        if (loggedInUser != null) {
            System.out.println("\n✅ Welcome, " + loggedInUser.getName());

            while (true) {
                // Show dashboard summary
                int totalTasks = TaskManager.getTasksForUser(loggedInUser.getId()).size();
                int completed = TaskManager.getCompletedTaskCount(loggedInUser.getId());
                int totalMinutes = TimerLogger.getTotalMinutes(loggedInUser.getId());

                System.out.println("\n📊 Dashboard Summary:");
                System.out.println("Tasks: " + totalTasks + " | Completed: " + completed + " | Focus Time: " + totalMinutes + " mins\n");

                System.out.println("1. View My Tasks");
                System.out.println("2. Add Task");
                System.out.println("3. Logout");
                System.out.println("4. Start Task Timer");
                System.out.print("Choose: ");

                int taskChoice = Integer.parseInt(sc.nextLine());

                if (taskChoice == 1) {
                    List<Task> tasks = TaskManager.getTasksForUser(loggedInUser.getId());
                    System.out.println("\n📋 Your Tasks:");
                    if (tasks.isEmpty()) {
                        System.out.println("(No tasks found!)");
                    } else {
                        for (Task t : tasks) {
                            System.out.println(t.getId() + ". " + t.getDescription() + " [" + t.getStatus() + "]");
                        }
                    }
                } else if (taskChoice == 2) {
                    System.out.print("Enter task description: ");
                    String desc = sc.nextLine().trim();
                    String tid = "T" + System.currentTimeMillis();
                    String time = String.valueOf(System.currentTimeMillis());
                    Task task = new Task(tid, loggedInUser.getId(), desc, "pending", time);

                    TaskManager.saveTask(task);
                    System.out.println("✅ Task added!");

                } else if (taskChoice == 3) {
                    System.out.println("👋 Logged out.");
                    break;
                } else if (taskChoice == 4) {
                    System.out.print("Enter task ID to start timer: ");
                    String tid = sc.nextLine().trim();

                    System.out.print("Enter duration in minutes: ");
                    int mins = Integer.parseInt(sc.nextLine().trim());

                    TimerService.startTimer(mins);
                    TimerLogger.logTimerSession(loggedInUser.getId(), tid, mins);
                } else {
                    System.out.println("❌ Invalid option.");
                }
            }
        }
    }
}
