import model.User;
import model.Task;
import service.AuthService;
import service.TaskManager;

import java.util.List;
import java.util.Scanner;

public class TestAuth {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("👤 Enter your name: ");
        String name = sc.nextLine();

        // Register or login the user
        User loggedInUser = AuthService.registerOrLogin(name);
        System.out.println("✅ Logged in as: " + loggedInUser.getName() + " (ID: " + loggedInUser.getId() + ")");

        // Task menu
        while (true) {
            System.out.println("\n📋 What would you like to do?");
            System.out.println("1. View My Tasks");
            System.out.println("2. Add New Task");
            System.out.println("3. Exit");
            System.out.print("➡ Choose an option: ");
            int choice = Integer.parseInt(sc.nextLine());

            if (choice == 1) {
                List<Task> tasks = TaskManager.getTasksForUser(loggedInUser.getId());
                if (tasks.isEmpty()) {
                    System.out.println("📭 No tasks yet.");
                } else {
                    System.out.println("📌 Your Tasks:");
                    for (Task t : tasks) {
                        System.out.println("- " + t.getDescription());
                    }
                }
            } else if (choice == 2) {
                System.out.print("📝 Enter task description: ");
                String desc = sc.nextLine();
                Task newTask = new Task(loggedInUser.getId(), desc);
                TaskManager.saveTask(newTask);
                System.out.println("✅ Task saved!");
            } else if (choice == 3) {
                System.out.println("👋 Goodbye!");
                break;
            } else {
                System.out.println("❌ Invalid choice. Try again.");
            }
        }

        sc.close();
    }
}
