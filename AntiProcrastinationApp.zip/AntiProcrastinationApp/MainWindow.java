// 📁 File: MainWindow.java
package ui;

import javax.swing.*;

import ui.LoginPanel;
import ui.RegisterPanel;


import ui.LoginPanel;
import ui.RegisterPanel;

import java.awt.*;

public class MainWindow extends JFrame {
    private CardLayout layout;
    private JPanel contentPanel;

    public MainWindow() {
        setTitle("⏳ Anti-Procrastination Task Manager");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        layout = new CardLayout();
        contentPanel = new JPanel(layout);
        LoginPanel login = new LoginPanel(this);
        RegisterPanel register = new RegisterPanel(this);

        // 🧩 Add UI panels (will be filled later)
        contentPanel.add(new LoginPanel(this), "login");
        contentPanel.add(new RegisterPanel(this), "register");
        contentPanel.add(new DashboardPanel(this), "dashboard");
        contentPanel.add(new TimerPanel(this), "timer");
        contentPanel.add(new TaskPanel(this), "tasks");
        mainPanel.add(login, "login");
        mainPanel.add(register, "register");

        add(contentPanel);
        layout.show(contentPanel, "login");
        layout.show(mainPanel, "login");
    }

    // 📌 Switch to a different panel
    public void switchTo(String panelName) {
        layout.show(contentPanel, panelName);
    }
}
