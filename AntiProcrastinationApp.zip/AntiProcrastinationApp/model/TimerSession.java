package model;

public class TimerSession {
    private String userId;
    private String taskId;
    private int minutes;
    private String timestamp;

    public TimerSession(String userId, String taskId, int minutes, String timestamp) {
        this.userId = userId;
        this.taskId = taskId;
        this.minutes = minutes;
        this.timestamp = timestamp;
    }

    public String getUserId() { return userId; }
    public String getTaskId() { return taskId; }
    public int getMinutes() { return minutes; }
    public String getTimestamp() { return timestamp; }

    @Override
    public String toString() {
        return userId + "," + taskId + "," + minutes + "," + timestamp;
    }

    public static TimerSession fromString(String line) {
        String[] parts = line.split(",", 4);
        return new TimerSession(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3]);
    }
}
