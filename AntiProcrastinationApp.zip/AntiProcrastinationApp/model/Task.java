package model;

public class Task {
    private String id;
    private String ownerId;
    private String description;
    private String status;
    private String timestamp;

    public Task(String id, String ownerId, String description, String status, String timestamp) {
        this.id = id;
        this.ownerId = ownerId;
        this.description = description;
        this.status = status;
        this.timestamp = timestamp;
    }

    public static Task fromString(String line) {
        String[] parts = line.split(",");
        return new Task(parts[0], parts[1], parts[2], parts[3], parts[4]);
    }

    public String toString() {
        return String.join(",", id, ownerId, description, status, timestamp);
    }

    public String getId() { return id; }
    public String getOwnerId() { return ownerId; }
    public String getDescription() { return description; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
