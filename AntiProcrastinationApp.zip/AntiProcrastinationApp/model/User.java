package model;

public class User {
    private String id;
    private String name;

    public User(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public static User fromString(String line) {
        String[] parts = line.split(",");
        if (parts.length >= 2) {
            return new User(parts[0], parts[1]);
        }
        return null;
    }

    @Override
    public String toString() {
        return id + "," + name;
    }
}
